[].forEach.call(document.querySelectorAll('.v-link .v-icon'), function (i) {
    i.click();
});